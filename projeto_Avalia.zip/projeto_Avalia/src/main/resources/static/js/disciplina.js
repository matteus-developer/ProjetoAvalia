const disciplina = document.querySelector("form");
const idDisciplina = document.querySelector(".disciplina");

// Função criada para receber os dados do campo da pagina e converter em JSON
function salvar() {
	fetch("http://localhost:8080/disciplina/salvar", {
		headers: {
			'Accept': 'application/json',
			'Content-Type': 'application/json'
		},
		method: "POST", //Determina qual tipo de ação será executada
		body: JSON.stringify({
			nomeDisciplina: idDisciplina.value
		})
	})
		.then(function(res) {
			console.log(res);
			//Verifica se a operação foi bem sucedida (código 2xx)**
			if (res.ok) {
				limpar(); // Limpa o campo apenas após o sucesso
				listarDisciplinas(); // Recarrega a lista para mostrar a nova disciplina
			} else {
				console.error("Erro ao salvar disciplina:", res.statusText);
			}
		})
		.catch(function(err) {
			console.error("Erro na requisição POST:", err);
		})
};

//Metodo para limpar o input da caixa de texto disciplina
function limpar(){
    // Use a variável 'idDisciplina' que já aponta para o input com a classe ".disciplina"
	idDisciplina.value = ""; 
    // Remova: const caixatexto = document.getElementById(disciplina);
    // Remova: caixatexto.value = "";
}

//FUNÇÃO PARA EXCLUIR DISCIPLINA
function excluirDisciplina(id) { // <-- Recebe o ID correto aqui
	if (!confirm(`Tem certeza que deseja excluir a disciplina com ID ${id}?`)) {
		return; // Cancela se o usuário não confirmar
	}

    // 💡 CORREÇÃO AQUI: Usa o parâmetro 'id' na URL
	fetch(`http://localhost:8080/disciplina/excluir/${id}`, { 
		method: "DELETE" 
	})
		.then(function(res) {
			console.log(res);
			if (res.ok) {
                // 💡 CORREÇÃO AQUI: Usa o parâmetro 'id' na mensagem
				console.log(`Disciplina com ID ${id} excluída com sucesso.`); 
				listarDisciplinas(); // Recarrega a lista
				// Não chame limpar() aqui, pois limparia o campo de texto desnecessariamente
			} else {
                // 💡 CORREÇÃO AQUI: Usa o parâmetro 'id' na mensagem
				console.error(`Erro ao excluir disciplina ${id}:`, res.statusText); 
			}
		})
		.catch(function(err) {
			console.error("Erro na requisição DELETE:", err);
		});
}


const tabelaBody = document.querySelector("#tableDisciplina tbody"); 
// Função para listar disciplinas e preencher a tabela
function listarDisciplinas() {
	fetch("http://localhost:8080/disciplina/list")
		.then(res => res.json())
		.then(disciplinas => {
			// Verifica se o elemento <tbody> foi encontrado
			if (document.querySelector("#tableDisciplina tbody")) {
				// 💡 Ação Correta: Limpa APENAS o corpo da tabela (<tbody>)
				(document.querySelector("#tableDisciplina tbody")).innerHTML = ""; 

				disciplinas.forEach(d => {
					const linha = document.createElement("tr");

					// Geração da linha de dados, incluindo o botão de exclusão
					linha.innerHTML = `
              <td>${d.idDisciplina}</td>
              <td>${d.nomeDisciplina}</td>
              <td>
                <button 
                    class="btn-excluir" 
                    data-id="${d.idDisciplina}"
                    title="Excluir Disciplina"
                >Excluir</button>
              </td>
            `;

					// Anexa a nova linha no corpo da tabela (<tbody>)
					(document.querySelector("#tableDisciplina tbody")).appendChild(linha);
				});

				// Adiciona event listeners aos botões recém-criados
				// O querySelectorAll deve ser feito após as linhas serem inseridas.
				document.querySelectorAll(".btn-excluir").forEach(button => {
					button.addEventListener('click', function() {
						const id = this.getAttribute('data-id');
						// Chama a função de exclusão que deve estar definida no seu script
						excluirDisciplina(id); 
					});
				});

			} else {
				console.error("O elemento <tbody> da tabela com ID #tableDisciplina não foi encontrado.");
			}
		})
		.catch(err => console.error("Erro ao listar disciplinas:", err));
}

disciplina.addEventListener('submit', function(event) {
	event.preventDefault();

	salvar();
});

// Chama a função ao carregar a página
document.addEventListener("DOMContentLoaded", listarDisciplinas);